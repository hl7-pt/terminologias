# Home Page - HL7 PT FHIR Implementation Guide: Terminologias v1.0.0

* [**Table of Contents**](toc.md)
* **Home Page**

## Home Page

| | |
| :--- | :--- |
| *Official URL*:http://hl7.pt/fhir/ImplementationGuide/hl7.fhir.pt.terminology | *Version*:1.0.0 |
| Active as of 2024-11-27 | *Computable Name*:TerminologyPT |

> A especificação aqui documentada é, por enquanto, uma especificação de prova de conceito e não pode ser usada para fins de implementação. Nenhuma responsabilidade pode ser inferida do uso ou mau uso desta especificação, ou de suas consequências.

### Âmbito

Esta publicação tal e tal

### Introdução

tal e tal

### IP e Licença

Não utilização de IP externo

### Autores e contribuidores

| | | | |
| :--- | :--- | :--- | :--- |
| Autor | zzz | xxxx | yyyy |
| Autor | xxx |  | dssd |
| Autor | asdasd | asdasd | asdas |
| Autor | asdasd |  | dasda |

