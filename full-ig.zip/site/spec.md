# Specification - HL7 PT FHIR Implementation Guide: Terminologias v1.0.0

* [**Table of Contents**](toc.md)
* **Specification**

## Specification

These are the project specifications:

